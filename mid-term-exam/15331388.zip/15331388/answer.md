# 美团外卖订票APP 业务建模

15331388

### 美团外卖用例图

![image-20180510145356218](assets/use_case.png)

### 订餐业务用例活动图

![image-20180510145452952](assets/activity.png)

### 领域模型

![image-20180510145523773](assets/domainModel.png)

### mealorder对象建模

![image-20180510145545583](assets/state.png)

### 订餐场景系统顺序图

![image-20180510145614286](assets/sequence.png)
